
Hey! Thanks for checking out my mayterials 2021 projects, an event hosted by people from @TheClubDiscord, go check them out!

https://twitter.com/TheClubDiscord
discord.gg/kjtQD3S

This is a bit like Nodevember but focused on material creation so they are mostly patterns/tiling stuff, though I don't expect these to be used in production (probably).

If you have trouble viewing some of the projects you will need Blender 2.93 (LTS or higher), which you can get it from this link:
https://www.blender.org/download/releases/2-93/

When you open the projects you should already be in the shader editor. If the nodes aren't visible they might be off-screen which you can bring them back by pressing the "HOME" button on your keyboard or via View > Frame All

The only HDRI  is "Palermo Sidewalk"  at 1K resolution which you can download from Poly Haven (formerly HDRI Haven) from here:
https://polyhaven.com/a/palermo_sidewalk

Happy Blender-ing!
--------
Twitter: @cmzw_
IG: @cmzw__
License: CC0
--------