Hey! Thanks for downloading my first nodevember2020 pack... 

Most of the time if you aren't able to view the nodes, it is mostly because they are off screen, which you can just recenter the shader editor by press the "Home" key on your keyboard. 

Note that some of the HDRI files got replaced with a 1k version in order to get the whole archive to less than 25MB for gumroad.

Should you have any other questions (hopefully I can answer them...),
You can find me either on:

Twitter: @cmzw_
Discord: DroppedBeat#6299
Happy Blender-ing!

HDRI Links:
abandoned_hopper_terminal_04_1k.hdr
https://hdrihaven.com/hdri/?h=abandoned_hopper_terminal_04

aft_lounge_1k.hdr
https://hdrihaven.com/hdri/?h=aft_lounge

carpentry_shop_02_2k.hdr (replaced with a 1k version)
https://hdrihaven.com/hdri/?h=carpentry_shop_02

delta_2_1k.hdr
https://hdrihaven.com/hdri/?h=delta_2

large_corridor_1k.hdr
https://hdrihaven.com/hdri/?h=large_corridor

leadenhall_market_1k.hdr
https://hdrihaven.com/hdri/?h=leadenhall_market

lilienstein_1k.hdr
https://hdrihaven.com/hdri/?h=lilienstein

moonlit_golf_1k.hdr
https://hdrihaven.com/hdri/?h=moonlit_golf

palermo_sidewalk_1k.hdr
https://hdrihaven.com/hdri/?h=palermo_sidewalk

quarry_02_1k.hdr
https://hdrihaven.com/hdri/?h=quarry_02

quattro_canti_2k.hdr (replaced with a 1k version)
https://hdrihaven.com/hdri/?h=quattro_canti

sunset_fairway_1k.hdr
https://hdrihaven.com/hdri/?h=sunset_fairway

the_lost_city_1k.hdr
https://hdrihaven.com/hdri/?h=the_lost_city